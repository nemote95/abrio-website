
import ir.abrio.dev.protocol.AbrioProtocol;
import ir.abrio.dev.sdk.AbrioComponent;


public class SampleComponent extends AbrioComponent {

    @Override
    public void receive(AbrioProtocol.BasicEvent message, Context context) {
        System.out.println("I'm multiply2 #"+id()+" and I've just received a message: \nTitle:"+message.getTitle()+"\nBody:"+message.getBody());

        AbrioProtocol.BasicEvent.Builder acknowledgeEvent = AbrioProtocol.BasicEvent.newBuilder();
        acknowledgeEvent.setTitle(message.getTitle());
        acknowledgeEvent.setBody(String.valueOf(Integer.parseInt(message.getBody())*2));
        context.send(acknowledgeEvent.build());
    }

    @Override
    public Integer id() {
        return 1;
    }
}
