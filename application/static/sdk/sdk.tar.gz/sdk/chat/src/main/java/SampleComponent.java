
import akka.actor.ActorRef;
import backend.EventPacket;
import ir.abrio.dev.protocol.AbrioProtocol;
import ir.abrio.dev.sdk.AbrioComponent;


public class SampleComponent extends AbrioComponent {

    ActorRef channel = null;
    @Override
    public void receive(AbrioProtocol.BasicEvent message, Context context) {
        System.out.println("I'm Chat component #"+id()+" and I've just received a message");

        if(channel==null)
            channel = createChannel(context);

        subscribeTo(channel,context.getSession());
        channel.tell(new EventPacket(message,context.getSession(),id()),getSelf());
    }

    @Override
    public Integer id() {
        return 3;
    }
}
