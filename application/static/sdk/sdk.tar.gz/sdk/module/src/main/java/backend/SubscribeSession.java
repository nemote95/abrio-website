package backend;

import akka.actor.ActorRef;

/**
 * Created by bardia on 4/17/16.
 */
public class SubscribeSession {
    public SubscribeSession(ActorRef clientSession){}
}
