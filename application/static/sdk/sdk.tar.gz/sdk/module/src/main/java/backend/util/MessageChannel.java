package backend.util;

/**
 * Created by bardia on 4/17/16.
 */
public class MessageChannel {
}
