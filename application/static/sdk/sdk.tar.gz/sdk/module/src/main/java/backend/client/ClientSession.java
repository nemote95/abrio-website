package backend.client;

import akka.actor.UntypedActor;

/**
 * Created by bardia on 3/29/16.
 */
public class ClientSession extends UntypedActor {
    @Override
    public void onReceive(Object message) throws Exception {

    }
}
