package backend;

import backend.client.ClientSession;
import ir.abrio.dev.protocol.AbrioProtocol;

/**
 * Created by bardia on 3/29/16.
 */
public class EventPacket {
    private AbrioProtocol.BasicEvent msg;
    private ClientSession session;
    private int from;
    public EventPacket(AbrioProtocol.BasicEvent msg,ClientSession session,int from){
        this.msg = msg;
        this.session = session;
        this.from = from;
    }

    public AbrioProtocol.BasicEvent msg() {
        return msg;
    }

    public ClientSession session() {
        return session;
    }

    public int from() {
        return from;
    }
}
